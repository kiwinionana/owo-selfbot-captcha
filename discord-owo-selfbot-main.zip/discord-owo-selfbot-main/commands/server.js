export default {
    info: "Support server link",
    callback: (message, ...args) => {
        message.reply("Join Our Support Server For Help: https://discord.gg/Yr92g5Zx3e")
    }
}